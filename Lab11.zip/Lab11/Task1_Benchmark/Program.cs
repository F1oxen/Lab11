using BenchmarkDotNet.Running;

BenchmarkRunner.Run<PrimesBenchmark>();
