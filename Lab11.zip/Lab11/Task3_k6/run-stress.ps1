$n = 1
$lastOk = 0
$failed = 0

while ($n -le 4096) {
    Write-Host "VUS=$n"
    k6 run -e VUS=$n --summary-export "result_$n.json" stress.js
    if ($LASTEXITCODE -ne 0) {
        $failed = $n
        break
    }
    $lastOk = $n
    $n = $n * 2
}

if ($failed -gt 0) {
    Write-Host "Repeat failed VUS=$failed"
    k6 run -e VUS=$failed --summary-export "result_${failed}_repeat.json" stress.js
    if ($lastOk -gt 0) {
        Write-Host "Repeat last successful VUS=$lastOk"
        k6 run -e VUS=$lastOk --summary-export "result_${lastOk}_repeat.json" stress.js
    }
}
