import http from 'k6/http';
import { check } from 'k6';

const vus = parseInt(__ENV.VUS || '1');

export const options = {
  vus: vus,
  duration: '15s',
  thresholds: {
    http_req_failed: ['rate<0.01'],
    http_req_duration: ['p(95)<500'],
  },
};

export default function () {
  const url = 'http://localhost:5080/password-hashes';
  const body = JSON.stringify({ password: 'LoadTest-Only-2026!' });
  const response = http.post(url, body, {
    headers: { 'Content-Type': 'application/json' },
    timeout: '2s',
  });
  check(response, { 'status is 200': (r) => r.status === 200 });
}
