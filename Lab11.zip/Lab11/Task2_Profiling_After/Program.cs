using System.Diagnostics;

class Program
{
    static void Main()
    {
        const string filePath = "server.log";
        if (!File.Exists(filePath))
            File.WriteAllLines(filePath, GenerateFakeLogs(10_000_000));

        var sw = Stopwatch.StartNew();
        var result = AnalyzeLogs(filePath);
        sw.Stop();

        Console.WriteLine($"Ошибок: {result.errorCount}, предупреждений: {result.warningCount}");
        Console.WriteLine($"Время выполнения: {sw.ElapsedMilliseconds} мс");
    }

    static (int errorCount, int warningCount) AnalyzeLogs(string path)
    {
        int errorCount = 0;
        int warningCount = 0;
        foreach (var line in File.ReadLines(path))
        {
            if (line.Contains("ERROR", StringComparison.Ordinal)) errorCount++;
            if (line.Contains("WARNING", StringComparison.Ordinal)) warningCount++;
        }
        return (errorCount, warningCount);
    }

    static IEnumerable<string> GenerateFakeLogs(int count)
    {
        var rand = new Random();
        string[] types = { "INFO", "WARNING", "ERROR" };
        for (int i = 0; i < count; i++)
        {
            yield return $"{DateTime.Now:HH:mm:ss} [{types[rand.Next(types.Length)]}] Message {i}";
        }
    }
}
