using System.Diagnostics;

class Program
{
    static void Main()
    {
        const string filePath = "server.log";
        if (!File.Exists(filePath))
            File.WriteAllLines(filePath, GenerateFakeLogs(10_000_000));

        var sw = Stopwatch.StartNew();
        var result = AnalyzeLogs(filePath);
        sw.Stop();

        Console.WriteLine($"Ошибок: {result.errorCount}, предупреждений: {result.warningCount}");
        Console.WriteLine($"Время выполнения: {sw.ElapsedMilliseconds} мс");
    }

    static (int errorCount, int warningCount) AnalyzeLogs(string path)
    {
        var lines = File.ReadAllLines(path);
        int errorCount = lines.Count(l => l.Contains("ERROR"));
        int warningCount = lines.Count(l => l.Contains("WARNING"));
        return (errorCount, warningCount);
    }

    static IEnumerable<string> GenerateFakeLogs(int count)
    {
        var rand = new Random();
        string[] types = { "INFO", "WARNING", "ERROR" };
        for (int i = 0; i < count; i++)
        {
            yield return $"{DateTime.Now:HH:mm:ss} [{types[rand.Next(types.Length)]}] Message {i}";
        }
    }
}
